function pintarTablas() {

	var filas =  parseInt(document.getElementById("filas").value, 10)

	var columnas = parseInt(document.getElementById("Columnas").value, 10)

	for (var i = 1; i<=filas;i++){
		var tr = document.createElement("tr")
		mitabla.appendChild("tr")

		for (var numeroFila = 1; i<=filas;numeroFila++) {
			var td = createElement("td")
			td.innerHTML = "Fila: " + i + ", Columna: " + numeroFila
			tr.appendChild("td")


		}
	}
}
